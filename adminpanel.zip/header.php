 <?php 

 include'db/session.php';

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="../images/harina logo.png">
  <title>Harina Cafe</title>

 <?php 

 include'template/template.php';

 ?>
 <style type="text/css">
 	div.dataTables_length select {
  color: #FFFF !important;
  background-color: #343a40 !important; 
}
table,td,th{
font-size: 12.5px !important;
}
.dataTables_length, .dataTables_filter, .dataTables_info, .dataTables_paginate {
	font-size: 13px !important;
}	

</style>
</head>
<body class="hold-transition dark-mode sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">



 <?php 
if ($Usertype =='1') {
 include'navigation.php';

}elseif($Usertype =='2'){
include'navigation2.php';
}
 ?>
  <?php 

 include'footer.php';

 ?>
</body>
</html>
