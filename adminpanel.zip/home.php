    <?php include 'header.php';
if ($Usertype =='1') {
 include'home1.php';

}elseif($Usertype =='2'){
include'home1.php';
}
 ?>