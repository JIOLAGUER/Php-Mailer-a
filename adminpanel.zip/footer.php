  <footer class="main-footer">
    <strong>Copyright &copy; 2023-2024 <a href="https://www.facebook.com/HarinaByMikawali">Harina Cafe</a>.</strong>
    All rights reserved.
  </footer>