<?php
include '../db/connect.php';

if (isset($_POST['id'])) {
    $id = $_POST['id'];

    $stmt = $connect->prepare("UPDATE `account` SET `Data_status`='0' WHERE id = ?");
    $stmt->bind_param("s", $id);
    $stmt->execute();

    if ($stmt) {
        echo "Retrieved";
    } else {
        echo "Error: " . mysqli_error($connect);
    }

    $stmt->close();
} else {
    echo "Error: ID not provided";
}

mysqli_close($connect);
?>