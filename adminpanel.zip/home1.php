<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<div class="content-wrapper">
    <!-- /.content-header -->

    <!-- Main content -->
    <br>
    <section class="content">
        <div class="container-fluid">
            <!-- Info boxes -->
            <div class="row">
                <div class="col-12 col-sm-6 col-md-3">
                    
                    <a href="admin_users">
                    <div class="info-box">
                        <span class="info-box-icon bg-info elevation-1"><i class="fas fa-users"></i></span>

                        <div class="info-box-content">
                            <span class="info-box-text">Users</span>
                            <?php
                              // Assuming $connect represents the database connection
                              $query = "SELECT COUNT(*) AS All_account FROM account ";
                              $count = 0; // Default value if the query fails or no results found

                              if ($result = $connect->query($query)) {
                                  $row = $result->fetch_assoc();
                                  $count = $row['All_account'];
                                  $result->free();
                              }
                              ?>
                            <span class="info-box-number"> <?php echo $count; ?> </span>
                        </div>
                        <!-- /.info-box-content -->
                    </div>
                    </a>
                    
                    <!-- /.info-box -->
                </div>
                <!-- /.col -->
                <div class="col-12 col-sm-6 col-md-3">
                    
                    <a href="customers">
                    <div class="info-box mb-3">
                        <span class="info-box-icon bg-danger elevation-1"><i class="fas fa-folder-open"></i></span>

                        <div class="info-box-content">
                            <span class="info-box-text">Customers</span>
                            <?php
                              // Assuming $connect represents the database connection
                              $query = "SELECT COUNT(*) AS all_customers FROM customers ";
                              $count = 0; // Default value if the query fails or no results found

                              if ($result = $connect->query($query)) {
                                  $row = $result->fetch_assoc();
                                  $count = $row['all_customers'];
                                  $result->free();
                              }
                              ?>
                            <span class="info-box-number"> <?php echo $count; ?> </span>
                        </div>
                        <!-- /.info-box-content -->
                    </div>
                    </a>
                    
                    
                    <!-- /.info-box -->
                </div>
                <!-- /.col -->

                <!-- fix for small devices only -->
                <div class="clearfix hidden-md-up"></div>

                <div class="col-12 col-sm-6 col-md-3">
                    <a href="menu">
                    <div class="info-box mb-3">
                        <span class="info-box-icon bg-success elevation-1"><i class="fas fa-folder-open"></i></span>

                        <div class="info-box-content">
                            <span class="info-box-text">Menus</span>
                            <?php
                              // Assuming $connect represents the database connection
                              $query = "SELECT COUNT(*) AS All_menu FROM menu WHERE availablestatus = 0 ";
                              $count = 0; // Default value if the query fails or no results found

                              if ($result = $connect->query($query)) {
                                  $row = $result->fetch_assoc();
                                  $count = $row['All_menu'];
                                  $result->free();
                              }
                              ?>
                            <span class="info-box-number"> <?php echo $count; ?> </span>
                        </div>
                        <!-- /.info-box-content -->
                    </div>
                    </a>
                    <!-- /.info-box -->
                </div>
                <!-- /.col -->

                <div class="col-12 col-sm-6 col-md-3">
                    <div class="info-box mb-3">
                        <span class="info-box-icon bg-primary elevation-1"><i class="fas fa-box"></i></span>

                        <div class="info-box-content">
                            <span class="info-box-text">Sold Products</span>
                            <?php
                              // Assuming $connect represents the database connection
                              $query = "SELECT SUM(quantity) AS total_sold_products FROM customer_orders WHERE order_status != 'Pending' AND order_status != 'Order Declined'";
                              $count = 0; // Default value if the query fails or no results found

                              if ($result = $connect->query($query)) {
                                  $row = $result->fetch_assoc();
                                  $count = $row['total_sold_products'];
                                  $result->free();
                              }
                              ?>
                            <span class="info-box-number"> <?php echo $count; ?> </span>
                        </div>
                        <!-- /.info-box-content -->
                    </div>
                    <!-- /.info-box -->
                </div>
                <!-- /.col -->


                <div class="col-12 col-sm-6 col-md-3">
                    <div class="info-box mb-3">
                        <span class="info-box-icon bg-primary elevation-1"><i class="fas fa-money-bill"></i></span>

                        <div class="info-box-content">
                            <span class="info-box-text">Total Revenue</span>
                            <?php
                              $query = "SELECT SUM(total_price) AS total_revenue FROM customer_orders WHERE order_status != 'Pending' AND order_status != 'Order Declined'";
                              $count = 0; // Default value if the query fails or no results found

                              if ($result = $connect->query($query)) {
                                  $row = $result->fetch_assoc();
                                  $count = $row['total_revenue'];
                                  $result->free();
                              }
                              ?>
                            <span class="info-box-number">₱ <?php echo $count; ?> </span>
                        </div>
                        <!-- /.info-box-content -->
                    </div>
                    <!-- /.info-box -->
                </div>
                <!-- /.col -->





            </div>
            <!-- /.row -->

            <div class="row">

            <div class="col-lg-6">
                <div class="card">
                <div class="card-title">
                    <h4> Sold Products Per Day </h4>
            
                </div>
                <div class="sales-chart">
                    <canvas id="myChart"></canvas>
                </div>
                </div>
                <!-- /# card -->
            </div>
            
            <div class="col-lg-6">
                <div class="card">
                <div class="card-title">
                    <h4> Revenue Per Day </h4>
            
                </div>
                <div class="sales-chart">
                    <canvas id="myChart2"></canvas>
                </div>
                </div>
                <!-- /# card -->
            </div>
            
            </div>
            <br><br>
            
            


            <!-- /.card-footer -->
        </div>
        <!-- /.card -->
</div>
<!-- /.col -->
</div>
<!-- /.row -->
</div>
<!--/. container-fluid -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->

<!-- Main Footer -->

</div>



<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
  <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap4.min.js"></script>


  <?php
// Assuming $connect represents the database connection
$query = "SELECT order_date, SUM(quantity) AS total_sold_products FROM customer_orders WHERE order_status != 'Pending' AND order_status != 'Order Declined' GROUP BY order_date";

if ($result = $connect->query($query)) {
    $data = array(); // Initialize an array to store data
    while ($row = $result->fetch_assoc()) {
        $data['labels'][] = $row['order_date'];
        $data['values'][] = $row['total_sold_products'];
    }
    $result->free();
} else {
    $data = array('labels' => array(), 'values' => array()); // Default empty data if the query fails
}
?>

<script>
  // Use PHP data in JavaScript
  const labels = <?php echo json_encode($data['labels']); ?>;
  const values = <?php echo json_encode($data['values']); ?>;

  // Create the chart
const ctx = document.getElementById('myChart').getContext('2d');
const myChart = new Chart(ctx, {
  type: 'bar',
  data: {
    labels: labels,
    datasets: [{
      label: 'Total Sold Products',
      backgroundColor: 'rgba(54, 162, 235, 0.5)',
      borderColor: 'rgba(54, 162, 235, 1)',
      borderWidth: 1,
      data: values,
    }]
  },
  options: {
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          callback: function(value, index, values) {
            return value + ' pcs'; // Adding "pcs" after the value
          }
        }
      }
    },
    plugins: {
      tooltip: {
        callbacks: {
          label: function(context) {
            let label = context.dataset.label || '';
            if (label) {
              label += ': ';
            }
            if (context.parsed.y !== null) {
              label += context.parsed.y + ' pcs'; // Adding "pcs" after the tooltip value
            }
            return label;
          }
        }
      }
    }
  }
});

</script>


<?php
// Assuming $connect represents the database connection
$query = "SELECT order_date, SUM(total_price) AS total_price FROM customer_orders WHERE order_status != 'Pending' AND order_status != 'Order Declined' GROUP BY order_date";

if ($result = $connect->query($query)) {
    $data = array(); // Initialize an array to store data
    while ($row = $result->fetch_assoc()) {
        $data['labels'][] = $row['order_date'];
        $data['values'][] = $row['total_price'];
    }
    $result->free();
} else {
    $data = array('labels' => array(), 'values' => array()); // Default empty data if the query fails
}
?>

<script>
  // Use PHP data in JavaScript
  const labels2 = <?php echo json_encode($data['labels']); ?>;
  const values2 = <?php echo json_encode($data['values']); ?>;

  // Create the chart
const ctx2 = document.getElementById('myChart2').getContext('2d');
const myChart2 = new Chart(ctx2, {
  type: 'bar',
  data: {
    labels: labels2,
    datasets: [{
      label: 'Total Revenue',
      backgroundColor: 'rgba(54, 162, 235, 0.5)',
      borderColor: 'rgba(54, 162, 235, 1)',
      borderWidth: 1,
      data: values2,
    }]
  },
  options: {
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          callback: function(value, index, values) {
            return '₱ ' + value; // Adding peso sign before the value
          }
        }
      }
    },
    plugins: {
      tooltip: {
        callbacks: {
          label: function(context) {
            let label = context.dataset.label || '';
            if (label) {
              label += ': ';
            }
            if (context.parsed.y !== null) {
              label += '₱ ' + context.parsed.y; // Adding peso sign before the tooltip value
            }
            return label;
          }
        }
      }
    }
  }
});

</script>





<script src="myjs/canvasjs.min.js"></script>