<?php

$project  = new PDO("mysql:host=localhost;dbname=u134790962_harinacafe", "u134790962_harina_cafe", "Harinacafe-123");

try {
    $output = ['data' => []];
    $i = 0;
    $stmt = $project->query("SELECT `id`, `Fullname`, `Usertype`, `Username`, `Password`, `Data_status`, `Date_created`, `active_status` FROM `account` where Data_status='1'");
    $stmt->execute();
    $t_sn = 1;
    while ($row = $stmt->fetch()) {
        $i++;
        $tools = '<button href="" id="'.$row["id"].'" class="Delete" style="border:none; background-color:transparent; color: #FFFF;"><i class="fas fa-redo-alt"></i></button>';
  
          
if ($row['Usertype'] == '1') {
  $Usertype = 'Administrator';
}else{
    $Usertype = 'Staff';
}

        

     $output['data'][] = [ 
      $row['Fullname'],
 $Usertype,
             $tools
        ];
         
    }
  
    $global_ = null;
    echo json_encode($output);

    return true;
} catch (PDOException $e) {
    $global_ = null;
    echo "Something went wrong. Please contact system administrator.";

}



?>