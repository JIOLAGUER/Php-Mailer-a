<?php

$project  = new PDO("mysql:host=localhost;dbname=harina", "root", "");

try {
    $output = ['data' => []];
    $i = 0;
    $stmt = $project->query("SELECT `id`, `Fullname`, `Usertype`, `Username`, `Password`, `Data_status`, `Date_created`, `active_status` FROM `account` where Data_status='0'");
    $stmt->execute();
    $t_sn = 1;
    while ($row = $stmt->fetch()) {
        $i++;
       $tools = '<a href="#" data-toggle="modal" data-target="#update" onclick="update('.$row['id'].')"><i class="fa fa-pen"></i></a> &nbsp; <button href="" id="' . $row["id"] . '" class="Delete" style="border:none; background-color:transparent; color: red;"><i class="fa fa-trash" style=""></i></button>';
  
          
if ($row['Usertype'] == '1') {
  $Usertype = 'Administrator';
}else{
    $Usertype = 'Staff';
}

        

     $output['data'][] = [ 
      $row['Fullname'],
 $Usertype,
             $tools
        ];
         
    }
  
    $global_ = null;
    echo json_encode($output);

    return true;
} catch (PDOException $e) {
    $global_ = null;
    echo "Something went wrong. Please contact system administrator.";

}



?>