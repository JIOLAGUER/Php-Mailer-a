<?php
include'../db/pdo.php';

try {
    $output = ['data' => []];
    $i = 0;
    $stmt = $connect->query("SELECT *, menu.id AS menuID, category.category AS categoryName FROM `menu` LEFT JOIN category on menu.category = category.id WHERE menu.datastatus = 0 ORDER BY menu.id DESC");
    $stmt->execute();
    $t_sn = 1;
    while ($row = $stmt->fetch()) {
    $i++;




 $output['data'][] = [
$row["name"],
$row["product_quantity"],
 $row["categoryName"]
        ];
         
    }
  


    $global_ = null;
    echo json_encode($output);

 return true;
} catch (PDOException $e) {
    $global_ = null;
    echo "Something went wrong. Please contact system administrator.";

}



