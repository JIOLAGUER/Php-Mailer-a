<?php

$connect = new mysqli('localhost', 'root', '', 'pis');

$countryId = isset($_POST['countryId']) ? $_POST['countryId'] : 0;

$command = isset($_POST['get']) ? $_POST['get'] : "";

switch ($command) {
    case "country":
        $statement = "SELECT * FROM city";
        $dt = mysqli_query($connect, $statement);
        while ($result = mysqli_fetch_array($dt)) {
            echo $result1 = "<option value='".$result['citymunDesc']."'>".$result['citymunDesc']."</option>";
        }       
        break;

    case "state":
        $result1 = "<option>-- Select Barangay --</option>";
        $statement = "SELECT * FROM `brgy` INNER Join city on brgy.citymunCode = city.citymunCode where city.citymunDesc='$countryId'";
        $dt = mysqli_query($connect, $statement);

        while ($result = mysqli_fetch_array($dt)) {
            $result1 .= "<option value='" . $result['brgyDesc'] . "'>" . $result['brgyDesc'] . "</option>";
        }
        echo $result1;
        break;


}

exit();
?>