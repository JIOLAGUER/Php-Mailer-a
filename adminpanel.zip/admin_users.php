 <?php
include'header.php';



?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap4.min.css">
<div class="content-wrapper">
  <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
          
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="home.php"><i class="fas fa-home"></i> Home</a></li>
              <li class="breadcrumb-item active">All Users</li>
            </ol>
          </div>
        </div>
    
  <!-- Employee Table--><!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table-->


        <div class="card">
            <div class="card-header " style="border:none;" >
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary btn-circle" data-toggle="modal" data-target="#modelId_Add">
                <i class="fas fa-plus"></i> Add
                </button>
                    <!-- Modal -->
                    <div class="modal fade" id="modelId_Add" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title">Add Admin User</h5>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                          </div>
                          <div class="modal-body">
                          <form action="insert/user.php" method="post">
                            <div class="mb-3">
                              <label for="" class="form-label">Full Name</label>
                              <input type="text" name="full_name" class="form-control" placeholder="Enter Full name" required />
                            </div>

                            <div class="mb-3">
                              <label for="" class="form-label">User Type</label>
                                <select class="form-control" name="userType" required>
                                  <option value="1">Administrator</option>
                                  <option value="2">Staff</option>
                                </select>
                            </div>

                            <div class="mb-3">
                              <label for="" class="form-label">Username</label>
                              <input type="text" name="username" class="form-control" placeholder="Enter username" required />
                            </div>

                            <div class="mb-3">
                              <label for="" class="form-label">Password</label>
                              <input type="password" name="password" class="form-control" placeholder="Enter password" required />
                            </div>

                            
                            
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button name="add_admin" class="btn btn-primary"><i class="fas fa-plus"></i> Add</button>
                          </div>
                          </form>

                        </div>
                      </div>
                    </div>


                    <br><br>
            <table id="example" class="table table-striped table-bordered" style="width:100%">
                  <thead>
                      <tr>
                          <th>Full Name</th>
                          <th>User Type</th>
                          <th>Action</th>
                      </tr>
                  </thead>
                  <tbody>
              <?php 
              include 'db/connect.php';
                    $sql = mysqli_query($connect, "SELECT * FROM account WHERE Data_status = '0' ");
                $menuItems = $sql->fetch_all(MYSQLI_ASSOC);
                    foreach ($menuItems as $row) {
                    ?>
                      <tr>
                          <td><?= $row['Fullname']?></td>
                          <td>
                              <?php
                                  if ($row['Usertype'] == 1) {
                                      echo "Administrator";
                                  } elseif ($row['Usertype'] == 2) {
                                      echo "Staff";
                                  } else {
                                      // Handle other cases if needed
                                      echo "Unknown Status";
                                  }
                              ?>
                          </td>

                          
                          <td>

                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-success btn-circle" data-toggle="modal" data-target="#modelId_confirm_<?= $row['id']?>">
                                    <i class="fas fa-pen"></i>
                                </button>
                                <button type="button" class="btn btn-danger btn-circle" data-toggle="modal" data-target="#modelId_delete_<?= $row['id']?>">
                                    <i class="fas fa-trash"></i>
                                </button>
                                

                                <!-- Modal -->
                                <div class="modal fade" id="modelId_confirm_<?= $row['id']?>" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
                                  <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <h5 class="modal-title">Update Admin User</h5>
                                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                          </button>
                                      </div>
                                      <div class="modal-body">
                                      <form action="update/user.php" method="post">
                                        <div class="mb-3">
                                        <input type="hidden" name="userID" value="<?= $row['id']?>" />
                                          <label for="" class="form-label">Full Name</label>
                                          <input type="text" name="full_name" class="form-control" placeholder="Enter Full name" value="<?= $row['Fullname']?>" aria-describedby="helpId" />
                                        </div>

                                        <div class="mb-3">
                                          <label for="" class="form-label">User Type</label>
                                            <select class="form-control" name="userType" id="">
                                              <option value="<?= $row['Usertype']?>" >
                                              <?php
                                                  if ($row['Usertype'] == 1) {
                                                      echo "Administrator";
                                                  } elseif ($row['Usertype'] == 2) {
                                                      echo "Staff";
                                                  } else {
                                                      // Handle other cases if needed
                                                      echo "Unknown Status";
                                                  }
                                              ?>
                                              </option>
                                              <option value="1">Administrator</option>
                                              <option value="2">Staff</option>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                          <label for="" class="form-label">Username</label>
                                          <input type="text" name="username" class="form-control" placeholder="Enter username" value="<?= $row['Username']?>" aria-describedby="helpId" />
                                        </div>

                                        <div class="mb-3">
                                          <label for="" class="form-label">Password</label>
                                          <input type="password" name="password" class="form-control" placeholder="Enter password" aria-describedby="helpId" />
                                        </div>

                                        
                                        
                                      </div>
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <button name="update" class="btn btn-success" >Update</button>
                                      </div>
                                      </form>

                                    </div>
                                  </div>
                                </div>


                                <div class="modal fade" id="modelId_delete_<?= $row['id']?>" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
                                  <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <h5 class="modal-title">Archive User</h5>
                                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                          </button>
                                      </div>
                                      <div class="modal-body">
                                        Are you sure you want to archive this user?
                                      </div>
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <a href="delete/archived_accounts.php?id=<?= $row['id']?>" class="btn btn-danger">Archive Admin</a>
                                      </div>
                                    </div>
                                  </div>
                                </div>


                          </td>
                      </tr>
                      <?php
                  }
                  ?>

                  </tbody>
                  <tfoot>
                      <tr>
                          <th>Full Name</th>
                          <th>User Type</th>
                          <th>Action</th>
                      </tr>
                  </tfoot>
              </table>
            </div>         
       </div><!-- /.container-fluid -->
    </section>
</div>
 


</div>
  <?php
include 'footer.php';


  ?>

  <!-- Include SweetAlert2 JS -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    <?php if (isset($_SESSION['title'], $_SESSION['text'], $_SESSION['icon'])): ?>
        Swal.fire({
            title: '<?php echo $_SESSION['title']; ?>',
            text: '<?php echo $_SESSION['text']; ?>',
            icon: '<?php echo $_SESSION['icon']; ?>',
            confirmButtonText: 'Okay'
        });
        <?php unset($_SESSION['title'], $_SESSION['text'], $_SESSION['icon']); ?>
    <?php endif; ?>
</script>



  <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
  <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap4.min.js"></script>

  <script>
	new DataTable('#example');
</script>



 <script src="assets/jquery.min.js"></script>

 
<script src="assets/jquery-3.5.1.js"></script>

 <script type="" src="assets/jszip.min.js"></script>
