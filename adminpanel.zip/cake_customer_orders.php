 <?php
include'header.php';



?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap4.min.css">
<div class="content-wrapper">
  <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
          
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="home.php"><i class="fas fa-home"></i> Home</a></li>
              <li class="breadcrumb-item active">All Orders</li>
            </ol>
          </div>
        </div>
    
  <!-- Employee Table--><!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table--> <!-- Employee Table-->


        <div class="card">
            <div class="card-header " style="border:none;" >

            <div class="table-responsive">
            <table id="example" class="table table-striped table-bordered" style="width:100%">
                  <thead>
                      <tr>
                          <th>Order Number</th>
                          <th>Customer Name</th>
                          <th>Customer Phone Number</th>
                          <th>Order Name</th>
                          <th>Order Details</th>
                          <th>Category</th>
                          <th>Price</th>
                          <th>Quantity</th>
                          <th>Total Price</th>
                          <th>Status</th>
                          <th>Action</th>
                      </tr>
                  </thead>
                  <tbody>
              <?php 
              include 'db/connect.php';
                    $sql = mysqli_query($connect, "SELECT *, customer_orders.price AS orderedPrice, customer_orders.id AS customer_ordersID, category.category AS categoryName  FROM `customer_orders` 
                    LEFT JOIN menu ON customer_orders.menu_id = menu.id 
                    LEFT JOIN customers ON customers.id = customer_orders.customer_id 
                    LEFT JOIN category ON category.id = menu.category WHERE category.id = '13' AND customer_orders.order_details = 'Whole Cake' ORDER BY customer_orders.id DESC ");
                $menuItems = $sql->fetch_all(MYSQLI_ASSOC);
                    foreach ($menuItems as $row) {
                    ?>
                      <tr>
                          <td><?= $row['order_number']?></td>
                          <td><?= $row['fullname']?></td>
                          <td><?= $row['contactnumber']?></td>
                          <td><?= $row['name']?></td>
                          <td><?= $row['order_details']?></td>
                          <td><?= $row['categoryName']?></td>
                          <td>₱ <?= $row['orderedPrice']?></td>
                          <td><?= $row['quantity']?></td>
                          <td>₱ <?= $row['total_price']?></td>
                          <td><?= $row['order_status']?></td>
                          <td>
                            <?php
                            $orderStatus = $row['order_status'];
                            ?>
                                <!-- Check if the order is not Declined or Confirmed -->
                                <?php if ($orderStatus == 'Pending') : ?>

                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-success btn-circle" data-toggle="modal" data-target="#modelId_confirm_<?= $row['customer_ordersID']?>">
                                    <i class="fas fa-check-circle"></i>
                                </button>
                                <button type="button" class="btn btn-danger btn-circle" data-toggle="modal" data-target="#modelId_delete_<?= $row['customer_ordersID']?>">
                                    <i class="fas fa-window-close"></i>
                                </button>

                                <?php endif; ?>

                                <!-- Modal -->
                                <div class="modal fade" id="modelId_confirm_<?= $row['customer_ordersID']?>" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
                                  <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <h5 class="modal-title">Confirm Order</h5>
                                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                          </button>
                                      </div>
                                      <div class="modal-body">
                                        Are you sure you want to confirm <?= $row['fullname']?> cake order?
                                      </div>
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <a href="cake_order_confirmation.php?confirmOrder=<?= $row['customer_ordersID']?>&customerEmail=<?= $row['email']?>&productName=<?= $row['name']?>&orderDetails=<?= $row['order_details']?>&orderedPrice=<?= $row['orderedPrice']?>&quantity=<?= $row['quantity']?>&totalPrice=<?= $row['total_price']?>&orderNumber=<?= $row['order_number']?>" class="btn btn-success">Confirm</a>
                                      </div>
                                    </div>
                                  </div>
                                </div>


                                <div class="modal fade" id="modelId_delete_<?= $row['customer_ordersID']?>" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
                                  <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <h5 class="modal-title">Decline Order</h5>
                                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                          </button>
                                      </div>
                                      <div class="modal-body">
                                        Are you sure you want to decline <?= $row['fullname']?> order?
                                      </div>
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <a href="cake_order_confirmation.php?declineOrder=<?= $row['customer_ordersID']?>&customerEmail=<?= $row['email']?>&productName=<?= $row['name']?>&orderDetails=<?= $row['order_details']?>&orderedPrice=<?= $row['orderedPrice']?>&quantity=<?= $row['quantity']?>&totalPrice=<?= $row['total_price']?>&orderNumber=<?= $row['order_number']?>" class="btn btn-danger">Decline Order</a>
                                      </div>
                                    </div>
                                  </div>
                                </div>


                          </td>
                      </tr>
                      <?php
                  }
                  ?>

                  </tbody>
                  <!-- <tfoot>
                      <tr>
                          <th>Order Number</th>
                          <th>Customer Name</th>
                          <th>Customer Phone Number</th>
                          <th>Order Name</th>
                          <th>Order Details</th>
                          <th>Category</th>
                          <th>Price</th>
                          <th>Quantity</th>
                          <th>Total Price</th>
                          <th>Status</th>
                          <th>Action</th>
                      </tr>
                  </tfoot> -->
              </table>
                </div>
            </div>         
       </div><!-- /.container-fluid -->
    </section>
</div>
 


</div>
  <?php
include 'footer.php';


  ?>

  <!-- Include SweetAlert2 JS -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    <?php if (isset($_SESSION['title'], $_SESSION['text'], $_SESSION['icon'])): ?>
        Swal.fire({
            title: '<?php echo $_SESSION['title']; ?>',
            text: '<?php echo $_SESSION['text']; ?>',
            icon: '<?php echo $_SESSION['icon']; ?>',
            confirmButtonText: 'Okay'
        });
        <?php unset($_SESSION['title'], $_SESSION['text'], $_SESSION['icon']); ?>
    <?php endif; ?>
</script>



  <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
  <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap4.min.js"></script>

  <script>
	new DataTable('#example');
</script>



 <script src="assets/jquery.min.js"></script>

 
<script src="assets/jquery-3.5.1.js"></script>

 <script type="" src="assets/jszip.min.js"></script>
