<?php
 $conn = mysqli_connect('localhost','root','','restaurant');

$id = $_POST['move_id'];
$Quantity = $_POST['Quantity'];









 $sql = mysqli_query($conn, "UPDATE `customer_order` SET `Quantity`='$Quantity' WHERE id = '$id'");


  if ($sql==true) {
    echo json_encode(array("statusCode"=>200));
  } 
  else {
    echo json_encode(array("statusCode"=>201));
  }


 mysqli_close($conn);
?>