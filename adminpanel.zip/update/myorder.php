<?php
 $conn = mysqli_connect('localhost','root','','restaurant');

$qrcoding = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ";
 $generate = substr(str_shuffle($qrcoding),0,8);

$id = $_POST['id'];


 $sql = mysqli_query($conn, "UPDATE `customer_order` SET `status`='1',`order_number`='$generate',`payment_status`='COD' WHERE customer_id = '$id' and status='0'");


  if ($sql==true) {
    echo json_encode(array("statusCode"=>200));
  } 
  else {
    echo json_encode(array("statusCode"=>201));
  }


 mysqli_close($conn);
?>