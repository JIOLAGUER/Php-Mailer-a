<?php
include '../db/connect.php';
session_start();




if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
    $fullname = $_POST['full_name'] ?? '';
    $role = $_POST['userType'] ?? '';
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if (!empty($password)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $id = $_POST['userID'] ?? '';

        $stmt = $connect->prepare("UPDATE `account` SET `Fullname`=?, `Usertype`=?, `Username`=?, `Password`=? WHERE id = ?");
        $stmt->execute([$fullname, $role, $username, $hashedPassword, $id]);

        if ($stmt->affected_rows > 0) {
            $_SESSION['title'] = 'Success';
            $_SESSION['text'] = 'Information Successfully Updated';
            $_SESSION['icon'] = 'success';
            
            // Redirect to home.php
            header('Location: ../admin_users.php');
        } else {
            $_SESSION['title'] = 'Warning';
            $_SESSION['text'] = 'You didnt change anything';
            $_SESSION['icon'] = 'info';
            
            // Redirect to home.php
            header('Location: ../admin_users.php');
        }

    }else{

        $id = $_POST['userID'] ?? '';

        $stmt = $connect->prepare("UPDATE `account` SET `Fullname`=?, `Usertype`=?, `Username`=? WHERE id = ?");
        $stmt->execute([$fullname, $role, $username, $id]);

        if ($stmt->affected_rows > 0) {
            $_SESSION['title'] = 'Success';
            $_SESSION['text'] = 'Information Successfully Updated';
            $_SESSION['icon'] = 'success';
            
            // Redirect to home.php
            header('Location: ../admin_users.php');
        } else {
            $_SESSION['title'] = 'Warning';
            $_SESSION['text'] = 'You didnt change anything';
            $_SESSION['icon'] = 'info';
            
            // Redirect to home.php
            header('Location: ../admin_users.php');
        }
           
    }

    

    // Close the statement
    $stmt->close();
    // Close the database connection
    mysqli_close($connect);
}




?>
