<?php
$conn = mysqli_connect('localhost','root','','restaurant');

if(isset($_POST["id"]))
{
$id = $_POST['id'];
 
  
    $sql ="UPDATE `customer_order` SET `status`='3' WHERE order_number = '$id'";
  if (mysqli_query($conn, $sql)) {
    echo json_encode(array("statusCode"=>200));
  } 
  else {
    echo json_encode(array("statusCode"=>201));
  }
  mysqli_close($conn);
 
}




?>