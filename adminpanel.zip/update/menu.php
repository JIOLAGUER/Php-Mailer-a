<?php
 include'../db/session.php';

$id = $_POST['ids'];
$Name = $_POST['Names'];
$Price = $_POST['Prices'];
$Quantity = $_POST['Quantity'];
$largeprice = $_POST['largeprice'];
$categorys = $_POST['categorys'];
$Decription = $_POST['Decriptions'];

$availability = $_POST['availability'];


$Decription = ucfirst($Decription);

$Decription = addslashes($Decription);

// Generate a unique filename for the updated image
$fileimage = $_FILES['file']['name'];
$filename = uniqid() . '-' . $fileimage;

$filetmpname = $_FILES['file']['tmp_name'];
$folder = '../../images/';
move_uploaded_file($filetmpname, $folder.$filename);
if ($fileimage == '') {

	
  $Name = ucfirst($Name);

  $Name = addslashes($Name);
  
   $sql = mysqli_query($connect, "UPDATE `menu` SET `name`='$Name',`largeprice`='$largeprice',`price`='$Price', `product_quantity`='$Quantity', `description`='$Decription',`category`='$categorys',availablestatus='$availability' WHERE id = '$id'");
  
  

}else{
$files = $filename;

$Name = ucfirst($Name);

$Name = addslashes($Name);

 $sql = mysqli_query($connect, "UPDATE `menu` SET `name`='$Name',`largeprice`='$largeprice',`price`='$Price',`description`='$Decription',`photo`='$files',`category`='$categorys',availablestatus='$availability' WHERE id = '$id'");


}


// $Name = ucfirst($Name);

// $Name = addslashes($Name);

//  $sql = mysqli_query($connect, "UPDATE `menu` SET `name`='$Name',`largeprice`='$largeprice',`price`='$Price',`description`='$Decription',`photo`='$files',`category`='$categorys',availablestatus='$availability' WHERE id = '$id'");


  if ($sql==true) {
    echo json_encode(array("statusCode"=>200));
  } 
  else {
    echo json_encode(array("statusCode"=>201));
  }


 mysqli_close($connect);
?>