   <?php include'header.php';?>
 <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <link rel="stylesheet" type="text/css" href="assets/daTables.min.css">
<style type="text/css">

</style>
    <div class="content-wrapper">
    <!-- /.content-header -->

    <!-- Main content -->
    <br>
    <section class="content">
      <div class="container-fluid">

        <div class="card">
      <div class="card-header">
          
          <div class="card-body">
              <a href=""  data-toggle="modal" data-target="#new" class="btn btn-primary" style="width: 100px; font-size: 14px;"><i class="fa fa-plus"></i> New</a>
<br><br>
            <table class="table table-striped " id="empTable" >
              <thead>
                <tr>
                
                <th >Fullname</th>
              
        
              <th >UserType</th>
                <th width="100">Action</th>
              </tr>
              </thead>
            
            </table>
            </div>
      
        </div>
<div id="new" class="modal fade">
 <div class="modal-dialog">
  <form method="post" id="new_user" enctype="multipart/form-data">
   <div class="modal-content">
    <div class="modal-header">
    
     <h4 class="modal-title">New User</h4>
      <button type="button" class="close" data-dismiss="modal">&times;</button>
    </div>
    <div class="modal-body">

<div class="form-group" >
                  <label for="Last">Fullname</label>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="fas fa-user-tie"></i></span>
                    </div>
<input type="text" class="form-control" placeholder="Fullname" id="Fullname" name="Fullname">
  
                  </div>
              </div>





<div class="form-group">
                  <label>Role</label>
                 
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class='fas fa-user-tie'></i> </span>
              
            <select class="form-control" name="Role" id="Role" required>
               
     
                             <option value=''>--Select Role--</option>
                            <option value='1'>Administrator</option>
                             <option value='2'>Staff</option>
                                 
                  

              

</select> 
                </div>
              </div>

    <div class="form-group">
                  <label for="Last">Username</label>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="fas fa-user-tie"></i></span>
                    </div>
<input type="text" class="form-control" placeholder="Username" id="Username" name="Username" minlength="6" maxlength="10">
  
                  </div>
              </div>


 <div class="form-group">
                  <label for="Last">Password</label>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="fas fa-user-tie"></i></span>
                    </div>
<input type="password" class="form-control" placeholder="**********" id="Password" name="Password" minlength="6" maxlength="10">
  
                  </div>
              </div>

                  
      


<br>


         
  
    </div>
    <div class="modal-footer">
     <input type="hidden" name="user_id" id="user_id" />
     <input type="hidden" name="operation" id="operation" />
     <?php if($Usertype == '1' ){?>
     <input type="submit" name="action" id="action" class="btn btn-primary" value="Submit" />
   <?php }?>
     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    </div>
   </div>
  </form>
 </div>
</div>




<div id="update" class="modal fade">
 <div class="modal-dialog">
  <form method="post" id="update_user" enctype="multipart/form-data">
   <div class="modal-content">
    <div class="modal-header">
    
     <h4 class="modal-title">Update User</h4>
      <button type="button" class="close" data-dismiss="modal">&times;</button>
    </div>
    <div class="modal-body">

<div class="form-group" >
                  <label for="Last">Fullname</label>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="fas fa-user-tie"></i></span>
                    </div>
<input type="text" class="form-control" placeholder="Fullname" id="Fullname_" name="Fullname_">
  
                  </div>
              </div>

              




<div class="form-group">
                  <label>Role</label>
                 
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class='fas fa-user-tie'></i> </span>
              
            <select class="form-control" name="Role_" id="Role_" required>
               
     
                           <option value=''>--Select Role--</option>
                            <option value='1'>Administrator</option>
                             <option value='2'>Staff</option>
                         
                                 
                  

              

</select> 
                </div>
              </div>

    <div class="form-group">
                  <label for="Last">Username</label>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="fas fa-user-tie"></i></span>
                    </div>
<input type="text" class="form-control" placeholder="Username" id="Username_" name="Username_" minlength="6" maxlength="10">
  
                  </div>
              </div>


 <div class="form-group">
                  <label for="Last">Password</label>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="fas fa-user-tie"></i></span>
                    </div>
<input type="password" class="form-control" placeholder="**********" id="Password_" name="Password_" minlength="6" maxlength="10">
  
                  </div>
              </div>

                  
      <input type="password" class="form-control" placeholder="**********" id="oldPassword" name="oldPassword" hidden>


<br>


         
  
    </div>
    <div class="modal-footer">
     <input type="hidden" name="user_id" id="user_id" />
     <input type="hidden" name="operation" id="operation" />
     <?php if($Usertype == '1' ){?>
     <input type="submit" name="action" id="action" class="btn btn-primary" value="Submit" />
   <?php }?>
     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    </div>
   </div>
  </form>
 </div>
</div>
<script type="assets/sweetalert.js"></script>
<script type="assets/sweetalert.min.js"></script>
<script src="assets/sweetalert2@11.js"></script>

<script src="assets/sweetalert2.min.js"></script>
 <script src="assets/jquery.min.js"></script>

 
<script src="assets/jquery-3.5.1.js"></script>


 <script src="assets/jquery.dataTables.min.js"></script>
 <script src="assets/dataTables.responsive.min.js"></script>


 <script src="assets/dataTables.buttons.min.js"></script>

 <script type="" src="assets/jszip.min.js"></script>

  <script src="assets/vfs_fonts.js"></script>
  <script src="assets/buttons.html5.min.js"></script>
  <script src="assets/buttons.print.min.js "></script>
<script>


$(document).ready(function(){
 $('#add_button').click(function(){
  $('#user_form')[0].reset();
  $('.modal-title').text("Add User");
  $('#action').val("Add");
  $('#operation').val("Add_blood_group");
  $('#user_uploaded_image').html('');
 });


 $('#empTable').DataTable({
        "ajax": {
            url: "fetch/account.php",
            type: "GET"
        },
        
        "paging": true,
     "paging": true,
        "lengthChange": true,
        "searching": true,
        "responsive": true,
        "ordering": true,
        "info": true
    });
});



$(document).on('submit', '#new_user', function(event){
  event.preventDefault();
  
Swal.fire({
  title: 'Are you sure you want to add this user?',
  text: '',
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Continue'
}).then((result) => {
  if (result.isConfirmed) {
     $.ajax({
    url:"insert/user.php",
    method:'POST',
    data:new FormData(this),
    contentType:false,
    processData:false,
    success:function(data)
    {
        
      
     if (data == 'saved') {
          Swal.fire('Data Saved Successfull!', '', 'success');
           $('#empTable').DataTable().ajax.reload();
         }else{
           Swal.fire(data, '', 'success');
         }
    }

   });
  }
  else
  {
   Swal.fire('Data Not Updated Successfull!', '', 'success');
  }
  })

 });



 $(document).on('click', '.Delete', function(){
  var id = $(this).attr("id");
  Swal.fire({
  title: 'Are you sure You want to Archived this user?',
  text: "",
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Continue'
}).then((result) => {
  if (result.isConfirmed) {
   $.ajax({
    url:"delete/archived_accounts.php",
    method:"POST",
    data:{id:id},
    success:function(mydata)
    {
  if(mydata === "Delete") {
          Swal.fire('User Archived Successfull!', '', 'success');
        $('#empTable').DataTable().ajax.reload();


      }else{
         Swal.fire(mydata, '', 'warning');
         
      }
   
    }
   });
  }
  else
  {
   return false; 
  }
})
 });

function update(id) {
    if (id) {
        $("#id").remove();
        $.ajax({
            url: 'fetch_single/user.php',
            type: 'POST',
            data: {
                id: id
            },
            dataType: 'json',

            success: function(result) {
               document.getElementById('Fullname_').value = result.Fullname;
   
                  document.getElementById('Role_').value = result.Usertype;
               document.getElementById('Username_').value = result.Username;
              
        
          document.getElementById('oldPassword').value = result.Password;
          










                $("#update_user").append('<input type="hidden" name="id" id="id" value="' + id + '"/>');
            }
        });
    }
}
$(document).on('submit', '#update_user', function(event){
  event.preventDefault();
  
Swal.fire({
  title: 'Are you sure you want to update this user?',
  text: '',
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Continue'
}).then((result) => {
  if (result.isConfirmed) {
     $.ajax({
    url:"update/user.php",
    method:'POST',
    data:new FormData(this),
    contentType:false,
    processData:false,
    success:function(data)
  {

      if(data == "User updated successfull") {
      Swal.fire(data, '', 'success');
         $('#empTable').DataTable().ajax.reload();
      }else{
          Swal.fire(data, '', 'warning');
      }
    
    }

   });
  }
  else
  {
   Swal.fire('Canceled!', '', 'info');
  }
  })

 });
</script>